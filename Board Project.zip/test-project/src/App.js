
import './assets/fonts/main.scss';
import './App.css';
import Banner from './components/Banner';
import Navigation from './layout/Navigation';
import Favorite from './layout/Favorite';
import TopGames from './layout/TopGames';
import Grid from './layout/Grid';
import TwoCol from './layout/TwoCol';
import Footer from './layout/footer';
import ListPanel from './components/ListPanel';

function App() {
  return (
    <div className="App">
     <Navigation />
      <Banner />
    <Favorite />
    <TopGames />
    <Grid />
    <TwoCol />

    <Footer />
    </div>
  );
}

export default App;