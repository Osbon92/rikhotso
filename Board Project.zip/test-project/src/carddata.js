import card1 from './assets/img/card1.png'
import card1profile from './assets/img/card1profile.png'
import card2 from './assets/img/card2.png'
import card2profile from './assets/img/card2profile.png';
import card3 from './assets/img/card3.png'
import card3profile from './assets/img/card3profile.png';
import card4 from './assets/img/card4.png'
import card4profile from './assets/img/card4profile.png';
import card5 from './assets/img/card5.png'
import card5profile from './assets/img/card6profile.png';
import card6 from './assets/img/card6.png'
import card6profile from './assets/img/card7profile.png';


export const carddata = [
    {
        picture: card1,

        caption:"core philosophies",
        name:"Cameron Williamson",
        company:"Gillette",
        ctacopy:"Live Demo",
        profile:card1profile

    },
    {
        picture:card2,
        caption:"core philosophies",
        name:"Dianne Russell",
        company:"Louis Vuitton",
        ctacopy:"Live Demo",
        profile:card2profile

    },
    {
        picture:card3,
        caption:"core philosophies",
        name:"Jane Cooper",
        company:"MasterCard",
        ctacopy:"Live Demo",
        profile:card3profile

    },
    {
        picture:card4,
        caption:"core philosophies",
        name:"Cody Fisher",
        company:"The Walt Disney Company",
        ctacopy:"Live Demo",
        profile:card4profile

    },
    {
        picture:card5,
        caption:"core philosophies",
        name:"Wade Warren",
        company:"Gillette",
        ctacopy:"Live Demo",
        profile:card5profile

    },
    {
        picture:card6,
        caption:"core philosophies",
        name:"Robert Fox",
        company:"L'Oréal",
        ctacopy:"Live Demo",
        profile:card6profile

    }
]