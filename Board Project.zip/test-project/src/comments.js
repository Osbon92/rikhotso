import Pic1 from './assets/img/Ellipse 12.png';
import pic2 from './assets/img/Ellipse 13.png';

export const comments = [
    {
        text:"One of the standout features of this gaming website is its extensive library of game guides and tutorials. It has helped me level up my skills, conquer challenging quests, and discover hidden secrets within games. The guides are comprehensive, easy to follow, and have undoubtedly elevated my gaming performance.",
        name:"Arlene McCoy",
        company:"McDonald's",
        image:Pic1
    },
    {
        text:"Another aspect that sets this website apart is its vibrant and passionate community. The forum section provides a platform for gamers from all walks of life to connect, share their experiences, and discuss their favorite titles. I've made valuable friendships and found like-minded individuals who share my enthusiasm for gaming.",
        name:"Kathryn Murphy",
        company:"General Electric",
        image:pic2
    }
]