
import ListPanel from "../components/ListPanel";
import Slider from "../components/Slider";
function Favorite(){

    return <section className="favorite">
         <ListPanel />
        <div className="container container--center">
            <h1 className="heading heading__primary  heading__primary--center">choose your<br /> <span className="text-bg"> FAvorite </span> games</h1>
            <p className="paragraph paragraph--center">Offer sneak peeks and previews of upcoming games, including trailers, screenshots, and information about release.</p>
        </div>
        
        <Slider />
        <div class="btn-container  center full-width">
                        <div class="skew skew--gradient skew--no-border center">
                         <a href="#" class="btn btn__primary  pd-large ">View All</a>
                         </div>
                         <div class="skew skew--no-gradient skew--bordered"> 
                         <a href="#" class="btn btn__primary text-bg  pd-large">Play now</a>
                         </div>
                    </div>
    </section>
}
export default Favorite;