import ListPanel from "../components/ListPanel";
import Logo from "../components/Logo";

function Footer(){

    return( <footer>
        <div className="footer">
        <div className="pos">
        <ListPanel />
        </div>
        <div className="footer__col">
            <div className="footer__content">
                <Logo />
                <p>
                A well-designed gaming header often 
                incorporates elements such as game characters,
                 iconic symbols, vibrant colors, and dynamic visuals .  
                </p>
            </div>
        </div>
        <div className="footer__col">
            <div className="footer__list">
               <h3>Company</h3>
                <ul>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Apps & games</a></li>
                    <li><a href="#">Features</a></li>
                </ul>
            </div>
        </div>
        <div className="footer__col">
        <div className="footer__list">
               <h3> help</h3>
                <ul>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div className="footer__col">
        <div className="footer__list">
               <h3>Resources</h3>
                <ul>
                    <li><a href="#">Youtube playlist</a></li>
                    <li><a href="#">How to - blog</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                </ul>
            </div>
        </div>
        </div>
    </footer>)
}


export default Footer;