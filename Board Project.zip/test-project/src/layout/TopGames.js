

function TopGames(){

    return <section className="favorite">
    
        <div className="container container--center">
            <h1 className="heading heading__primary  heading__primary--center">welcome to the <br />  top <span className="text-bg"> games </span></h1>
           
        </div>
        
       
        <div class="btn-container  center full-width">
                        <div class="skew skew--gradient skew--no-border center">
                         <a href="#" class="btn btn__primary  pd-small ">View All</a>
                         </div>
                         <div class="skew skew--no-gradient skew--bordered"> 
                         <a href="#" class="btn btn__primary text-bg  pd-small light-font">Newest games</a>
                         </div>
                         <div class="skew skew--no-gradient skew--bordered"> 
                         <a href="#" class="btn btn__primary text-bg  pd-small light-font">Latest games</a>
                         </div>
                         <div class="skew skew--no-gradient skew--bordered"> 
                         <a href="#" class="btn btn__primary text-bg  pd-small light-font">Fight games</a>
                         </div>
                         <div class="skew skew--no-gradient skew--bordered"> 
                         <a href="#" class="btn btn__primary   pd-small light-font">sport games</a>
                         </div>
                    </div>
    </section>
}
export default TopGames;