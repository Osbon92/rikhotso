import { carddata } from "../carddata";
import Card from '../components/card';
function Grid(){

    return <div className="grid">
        {
            carddata.map(data =>{
            return (<div className="grid-item">
                     <Card buildData={data} />
            </div>)
            }
            )
        }
    </div>
}
export default Grid;