import { Lock } from "../components/Lock";
import Logo from "../components/Logo";
import Nav from "../components/Nav";
function Navigation(){
    return <nav className="nav">
                <Logo />
                <Nav />
                <Lock />
            </nav>
}
export default Navigation;