
import{comments} from '../comments';
import Comments from '../components/Comments';
function TwoCol(){
    return <div className='col2'>
        { comments.map(com=> <Comments comment={com} />)}
    </div>
}
export default TwoCol;