
function Nav(){
 return (<ul className="nav__list">
            <li className="nav__list-item"><a className="nav__link nav__link--bold" href="#">Products</a></li>
            <li className="nav__list-item"><a className="nav__link" href="#">Apps & Games</a></li>
            <li className="nav__list-item"><a className="nav__link" href="#">Features</a></li>
            <li className="nav__list-item"><a className="nav__link" href="#">Support</a></li>
            <li className="nav__list-item"><a className="nav__link" href="#">About</a></li>
        </ul>)
}
export default Nav;