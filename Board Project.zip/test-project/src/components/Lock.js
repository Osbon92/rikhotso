import lock from '../../src/assets/img/lockicon.png';
export const Lock = ()=><div className='lock-icon'><img src={lock} alt='nav lock icon' /></div>;