import ImageA from '../assets/img/slider-1.png';
import ImageB from '../assets/img/slider-2.png';
import ImageC from '../assets/img/slider-3.png';
import Logosmall from '../assets/img/logosmall.png';
import Borders from '../assets/img/borders.png';



function Slider(){

    return (
        <div className="row">
            <div className="slider">
                <div className="slide">
                    <img src={ImageA} alt="first slide" className="slide__image" style={{width:"100%"}} />
                </div>
                <div className="slide slide--center">
                     <div className='circle'>
                        <img src={Logosmall} alt='small logo' />
                     </div>
                   <div className='slide-image-container'>
                    <div className='borders'>
                     
                    </div>
                   
                   <img src={ImageB} alt="second slide" className="slide__image slide__image--center" />
                   <div className='bottom-text'>
                    <p class="slider-text">sneak peeks</p>
                   </div>
                   </div>
                </div>
                <div className="slide">
                    <img src={ImageC} alt="second slide" className="slide__image" style={{width:"100%"}} />
                </div>
            

            </div>


        </div>
    )
}
export default Slider;