
function Comments({comment}){

    return <div className="card-container ">
        <div className="card card__comments">
            <div className="marker">
                <div className="marker-left" />
                <div className="marker-right" />
            </div>
            <div className="comment-text">
                <p>{comment.text}</p>
            </div>
            <div className="card__bottom mt-small">
               <div className="card__profile">
               <img src={comment.image} alt="comment profile picture" />
                <div className="card__discription pd-small">
                    <p>{comment.name}</p>
                    <p>{comment.company}</p>
                </div>
               </div>
               <div>
                 <p className="verify">Verified</p>
               </div>
            </div>
        </div>
    </div>
}

export default Comments;