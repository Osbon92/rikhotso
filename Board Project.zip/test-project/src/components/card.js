
function Card({buildData}){

    return (
        <div className="card-container">
            <div className="card">
                <div className="card__heading">
                    <img src={buildData.picture} alt="card image" className="card__heading-picture" />
                    <div className="card__heading-caption">
                        <p>{buildData.caption}</p>
                    </div>
                </div>
                <div className="card__profile">
                    <div className="card__profile-picture">
                        <img src={buildData.profile} alt="card profile picture" />
                       
                    </div>
                   <div className="card__description">
                     <p className="card__profile-name">{buildData.name}</p>
                    <p className="card__profile-company">{buildData.company}</p>
                    </div>
                </div>

                <div className="skew skew--gradient skew--no-border card__btn pd-small">
                    <a href="" className="" >{buildData.ctacopy}</a>
                </div>
               
            </div>
        </div>
    )
}
export default Card;