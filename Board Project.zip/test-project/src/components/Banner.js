import Navigation from "../layout/Navigation";


function Banner(){
    return (
            <header className="banner">
               
                <div className="banner__content">
                    <div className="heading">
                        <h1 className="heading__primary">
                            Let your   <br />mind
                            <span className="text-gradient text-bg" style={{marginLeft:10+'px'}}> explore</span>
                            <br />
                            new world
                            </h1>

                    </div>
                    <div className="paragraph">
                        <p className="paragraph__primary">
                        Playing electronic games, whether through consoles,
                         computers, mobile phones or another medium altogether.
                         Gaming is a nuanced term that suggests regular gameplay, 
                         possibly as a hobby.
                        </p>
                    </div>
                    <div className="btn-container">
                       <div className="skew skew--gradient skew--no-border"> <a href="#" className="btn btn__primary ">Buy now</a></div>
                       <div className="skew skew--no-gradient skew--bordered"> <a href="#" className="btn btn__primary text-bg">Play now</a></div>
                    </div>
                    <div className="ratings">
                        <div>
                            <h6>300+</h6>
                            <p>Unique style</p>
                        </div>
                        <div>
                            <h6 className="text-bg">200+</h6>
                            <p>Project finished</p>
                        </div>
                        <div>
                            <h6>500+</h6>
                            <p>Happy customer</p>
                        </div>
                    </div>

                </div>
               
            
            </header>
    )
}
export default Banner;