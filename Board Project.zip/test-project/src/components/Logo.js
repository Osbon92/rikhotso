import logoImage from '../../src/assets/img/logo.png';
function Logo(){
    return <div className="brand">
        <img src={logoImage} alt='brand logo' className='brand__logo' />
        <div className='brand__label'>board</div>
    </div>
}
export default Logo;