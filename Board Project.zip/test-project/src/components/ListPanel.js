
function ListPanel(){

    return (<div className="list-panel">
                <ul className="list-panel__list move-left">
                    <li className="list-panel__item">
                        Gaming spaning
                    </li>
                    <li className="list-panel__item">
                         Action - packed
                    </li>
                    <li className="list-panel__item">
                        mind - bending
                    </li>
                    <li className="list-panel__item">
                        collection og games
                    </li>
                </ul>
            </div>)
}

export default ListPanel;